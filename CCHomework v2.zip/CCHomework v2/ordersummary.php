<?php
session_start();

$num_sticks = $_POST["drumstick"];
$num_pack = $_POST["drumhead"];
$num_set = $_POST["drumset"];

$sticks = $num_sticks * 19.99;
$pack = $num_pack * 139.99;
$set = $num_set * 8999.99;
$subtotal = $set + $sticks + $pack;

$_SESSION['subtotal'] = $subtotal;
?>


<!doctype html>
<html>
    <head>
        <title>Order Summary</title>
    </head>
    <body>
        <h1><b>Order Summary</h1>
        <hr>
        <br>

        <?php
        echo "Your subtotal is \$$subtotal";
        ?>
        <br>

        <form action="tax.php" method="post">
            <br><input type="submit" value="Confirm">

        </form>



    </body>
</html>