<!doctype html>
<html>
    <head>
        <title>Order Form</title>
    </head>
    <body>
        <h1><b>Order Form</h1>
        <hr>
        <br>
        <form action="ordersummary.php" method="post"> 

            Promark Drumsticks 5a: <input type="number" name="drumstick"> $19.99<br>
            <br>
            <br>
            Remo Silent Stroke Mesh Drum Head 5-Pack (14",12",13",16",22") : <input type="number" name="drumhead"> $139.99<br>
            <br>
            <br>
            Roland VAD716 Electronic Drum Set: <input type="number" name="drumset"> $8,999.99<br>
            <br>
            <input type="submit">





        </form>



    </body>
</html>