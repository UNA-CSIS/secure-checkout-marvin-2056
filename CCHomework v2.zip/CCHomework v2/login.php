<?php
session_start();

?>

<!doctype html>
<html>
    <head>
        <title>Log in</title>
    </head>
    <body>
        <h1><b>Log In to continue to checkout</h1>
        <hr>
        <br>
        <form action="loginvalid.php" method="post"> 

            Username: <input type="text" name="usr"><br>
            <br>
            <br>
            Password: <input type="password" name="pw"><br>
            <br>
            <br>
            <input type="submit">





        </form>



    </body>
</html>